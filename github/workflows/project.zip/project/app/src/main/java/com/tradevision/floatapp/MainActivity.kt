package com.tradevision.floatapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var actionButton: Button
    private lateinit var bodyText: TextView

    private val notificationPermissionCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        actionButton = findViewById(R.id.actionButton)
        bodyText = findViewById(R.id.bodyText)

        actionButton.setOnClickListener { onActionButtonClicked() }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun refreshUi() {
        if (!Settings.canDrawOverlays(this)) {
            bodyText.setText(R.string.grant_permission_body)
            actionButton.setText(R.string.grant_permission_button)
        } else if (FloatingBubbleService.isRunning) {
            bodyText.text = "TradeVision is floating. You can switch to any other app now — the bubble stays on top. Tap it any time to reopen the dashboard."
            actionButton.setText(R.string.stop_floating_button)
        } else {
            bodyText.text = "Permission granted. Tap below to start the floating bubble, then switch to any app you like."
            actionButton.setText(R.string.start_floating_button)
        }
    }

    private fun onActionButtonClicked() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            return
        }

        if (FloatingBubbleService.isRunning) {
            stopService(Intent(this, FloatingBubbleService::class.java))
            refreshUi()
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                notificationPermissionCode
            )
            return
        }

        startFloatingService()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == notificationPermissionCode) {
            startFloatingService()
        }
    }

    private fun startFloatingService() {
        val serviceIntent = Intent(this, FloatingBubbleService::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "Floating bubble started. Try switching apps!", Toast.LENGTH_LONG).show()
        moveTaskToBack(true)
        refreshUi()
    }
}
