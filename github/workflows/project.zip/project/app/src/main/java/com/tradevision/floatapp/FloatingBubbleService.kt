package com.tradevision.floatapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import android.widget.ImageView
import kotlin.math.abs

class FloatingBubbleService : Service() {

    companion object {
        var isRunning: Boolean = false
        private const val CHANNEL_ID = "tradevision_float_channel"
        private const val NOTIFICATION_ID = 42
        private const val CLICK_DRAG_THRESHOLD = 12
        private const val MIN_PANEL_WIDTH = 280
        private const val MIN_PANEL_HEIGHT = 320
        const val ACTION_STOP = "com.tradevision.floatapp.ACTION_STOP"
    }

    private lateinit var windowManager: WindowManager

    private var bubbleView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var panelView: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var webView: WebView? = null

    private var panelExpanded = false

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(NOTIFICATION_ID, buildNotification())
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        removeBubble()
        removePanel()
        webView?.destroy()
    }

    // ---------- Notification ----------

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_MIN
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val openIntent = Intent(this, MainActivity::class.java)
        val openPendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    // ---------- Bubble ----------

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

    private fun addBubble() {
        if (bubbleView != null) return

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.layout_bubble, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 24
        params.y = 200

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var totalMovement = 0f

        view.findViewById<ImageView>(R.id.bubbleIcon).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    totalMovement = 0f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    totalMovement += abs(dx) + abs(dy)
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (totalMovement < CLICK_DRAG_THRESHOLD) {
                        toggleExpandedPanel()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, params)
        bubbleView = view
        bubbleParams = params
    }

    private fun removeBubble() {
        bubbleView?.let {
            runCatching { windowManager.removeView(it) }
        }
        bubbleView = null
    }

    private fun setBubbleVisible(visible: Boolean) {
        bubbleView?.visibility = if (visible) View.VISIBLE else View.GONE
    }

    // ---------- Expanded panel ----------

    private fun toggleExpandedPanel() {
        if (panelExpanded) {
            hidePanel()
        } else {
            showPanel()
        }
    }

    private fun showPanel() {
        if (panelView == null) {
            createPanel()
        }
        panelView?.visibility = View.VISIBLE
        setBubbleVisible(false)
        panelExpanded = true
    }

    private fun hidePanel() {
        panelView?.visibility = View.GONE
        setBubbleVisible(true)
        panelExpanded = false
    }

    private fun createPanel() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.layout_floating_window, null)

        val displayMetrics = resources.displayMetrics
        val defaultWidth = (displayMetrics.widthPixels * 0.9).toInt()
        val defaultHeight = (displayMetrics.heightPixels * 0.75).toInt()

        val params = WindowManager.LayoutParams(
            defaultWidth,
            defaultHeight,
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = (displayMetrics.widthPixels - defaultWidth) / 2
        params.y = (displayMetrics.heightPixels - defaultHeight) / 4

        setupWebView(view, defaultWidth, defaultHeight)
        setupDrag(view, params)
        setupResize(view, params)

        view.findViewById<ImageButton>(R.id.closeButton).setOnClickListener {
            stopSelf()
        }
        view.findViewById<ImageButton>(R.id.minimizeButton).setOnClickListener {
            hidePanel()
        }

        windowManager.addView(view, params)
        panelView = view
        panelParams = params
    }

    private fun setupWebView(root: View, initialWidth: Int, initialHeight: Int) {
        val wv = root.findViewById<WebView>(R.id.dashboardWebView)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.loadWithOverviewMode = true
        wv.settings.useWideViewPort = true
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.webViewClient = WebViewClient()
        wv.webChromeClient = WebChromeClient()
        wv.loadUrl("file:///android_asset/tradevision_pro.html")
        webView = wv
    }

    private fun setupDrag(root: View, params: WindowManager.LayoutParams) {
        val titleBar = root.findViewById<View>(R.id.titleBar)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        titleBar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(root, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupResize(root: View, params: WindowManager.LayoutParams) {
        val handle = root.findViewById<View>(R.id.resizeHandle)

        var initialWidth = 0
        var initialHeight = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialWidth = params.width
                    initialHeight = params.height
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val newWidth = initialWidth + (event.rawX - initialTouchX).toInt()
                    val newHeight = initialHeight + (event.rawY - initialTouchY).toInt()
                    params.width = newWidth.coerceAtLeast(MIN_PANEL_WIDTH)
                    params.height = newHeight.coerceAtLeast(MIN_PANEL_HEIGHT)
                    windowManager.updateViewLayout(root, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun removePanel() {
        panelView?.let {
            runCatching { windowManager.removeView(it) }
        }
        panelView = null
        panelExpanded = false
    }
}
