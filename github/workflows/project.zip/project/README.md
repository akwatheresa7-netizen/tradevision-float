# TradeVision Float

A native Android wrapper that lets your **TradeVision Pro** dashboard float on top of
any other app, like a Messenger chat head — tap the bubble to expand the full
dashboard, drag it around, resize it, or collapse it back to a bubble, all while
using other apps.

This is a real Android app project (Kotlin), not a website. A website/PWA cannot
draw over other apps — that requires the `SYSTEM_ALERT_WINDOW` permission, which is
only available to installed native apps. That's what this project is.

## What's inside

- `app/src/main/assets/tradevision_pro.html` — your original dashboard file, embedded as-is
- `FloatingBubbleService.kt` — a foreground service that draws the draggable bubble
  and the expandable panel (with a `WebView` running your dashboard) using
  `WindowManager` overlays
- `MainActivity.kt` — a one-time setup screen that asks for the "Display over other
  apps" permission and starts/stops the floating bubble

Your dashboard still calls the live Binance API for prices exactly as it did in the
browser — internet permission is included.

## How to build it (you'll need Android Studio — this can't be compiled on this end)

1. Install [Android Studio](https://developer.android.com/studio) if you don't have it.
2. Unzip this project and open the folder in Android Studio (`File > Open`).
3. Let it sync — Android Studio will automatically download the correct Gradle
   version and SDK components the first time (this needs internet access on your
   computer).
4. Plug in your Android phone via USB with **USB debugging** enabled (Settings >
   Developer options), or use Android Studio's built-in emulator.
5. Click the green ▶ **Run** button, choosing your device. This installs the app.

Alternatively, to get an installable file without a cable:
`Build > Build App Bundle(s) / APK(s) > Build APK(s)`, then find the `.apk` under
`app/build/outputs/apk/debug/`, and send it to your phone (email, Drive, etc.) to
install directly.

> Your phone will warn about installing an app from outside the Play Store the
> first time — that's expected for a personal/sideloaded app. You'll need to allow
> installs from that source in Settings.

## How to use it on your phone

1. Open **TradeVision Float** from your app drawer.
2. Tap **Grant permission** → enable **"Display over other apps"** for TradeVision
   Float on the system settings screen that opens → go back to the app.
3. Tap **Start floating**. The app will drop to the background and a small round
   bubble will appear on your screen.
4. Switch to any other app (browser, another trading app, whatever) — the bubble
   stays on top.
5. Tap the bubble to expand the full dashboard. Drag the title bar to move it, drag
   the bottom-right corner to resize it, tap the down-arrow to collapse back to a
   bubble, or tap ✕ to close it entirely.
6. A persistent notification ("TradeVision is floating") stays while it's running —
   tap **Stop** there, or toggle it off from the app, to turn it off.

## Notes / limitations

- This targets Android 7.0 (API 24) and up.
- The floating panel keeps running only while the service is alive; force-closing
  the app from the recent-apps/task switcher will stop it, same as any other
  floating-bubble app (e.g. Messenger chat heads).
- If you want the bubble to snap to screen edges, remember its last position, or
  add a settings screen, that's a straightforward addition to
  `FloatingBubbleService.kt` — just ask and I can extend it.
